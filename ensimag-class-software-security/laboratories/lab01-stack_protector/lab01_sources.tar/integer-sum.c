#include <stdio.h>


const int M=-1 ;


int main() {

    int x ; // user input 
    int sum=0 ;  // sum of the user inputs


    printf("enter an integer value (-1 to end)\n") ;

    scanf ("%d", &x) ;

    while (x != M) {
	sum = sum + x ;  
        printf("enter an integer value (-1 to end)\n") ;
	scanf ("%d", &x) ;
    } ;  


    printf("the sum of your inputs is %d \n", sum) ;

   return 0 ;

}
